<?php

mysql_connect("localhost","root","") or exit("Gagal koneksi database!");
mysql_select_db("db_pw") or exit("Gagal mengaktifkan database!");

?>