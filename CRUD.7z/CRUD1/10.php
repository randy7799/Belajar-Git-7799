<html>
	<head>
		<title>Tambah Data</title>
	</head>
<body>
	<form action="11.php" method="post">
		Nama : &nbsp;<input type="text" name="txtNama" />
		<br />
		Alamat : <textarea name="txtAlamat"></textarea>
		<br />
		<input type="submit" value="Submit" />
	</form>
</body>
</html>